package iotbay.model;

public enum UserType{
    CUSTOMER, STAFF;
}
